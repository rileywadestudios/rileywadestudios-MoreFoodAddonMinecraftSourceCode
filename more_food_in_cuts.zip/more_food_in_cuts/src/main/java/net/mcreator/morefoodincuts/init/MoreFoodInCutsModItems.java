
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.morefoodincuts.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.Item;

import net.mcreator.morefoodincuts.item.TomatoItem;
import net.mcreator.morefoodincuts.item.SplatedTomatoItem;
import net.mcreator.morefoodincuts.item.SplatedPumpkinItem;
import net.mcreator.morefoodincuts.item.SlicedTomatoItem;
import net.mcreator.morefoodincuts.item.PumpkinItem;
import net.mcreator.morefoodincuts.item.CarvedPumkinItem;
import net.mcreator.morefoodincuts.MoreFoodInCutsMod;

public class MoreFoodInCutsModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, MoreFoodInCutsMod.MODID);
	public static final RegistryObject<Item> TOMATO = REGISTRY.register("tomato", () -> new TomatoItem());
	public static final RegistryObject<Item> SPLATED_TOMATO = REGISTRY.register("splated_tomato", () -> new SplatedTomatoItem());
	public static final RegistryObject<Item> SLICED_TOMATO = REGISTRY.register("sliced_tomato", () -> new SlicedTomatoItem());
	public static final RegistryObject<Item> PUMPKIN = REGISTRY.register("pumpkin", () -> new PumpkinItem());
	public static final RegistryObject<Item> SPLATED_PUMPKIN = REGISTRY.register("splated_pumpkin", () -> new SplatedPumpkinItem());
	public static final RegistryObject<Item> CARVED_PUMKIN = REGISTRY.register("carved_pumkin", () -> new CarvedPumkinItem());
}
